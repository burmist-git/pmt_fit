#!/bin/sh
CDS_CONCEPT_HDL=TRUE;export CDS_CONCEPT_HDL
cd /exp/elec/dinaucou/CAO/JJeglot/pm_e678_testboard_v2
netassembler
concept2cm -forward -export -proj "/exp/elec/dinaucou/CAO/JJeglot/pm_e678_testboard_v2/pmtpcb.cpm"
pxl.exe -proj "/exp/elec/dinaucou/CAO/JJeglot/pm_e678_testboard_v2/pmtpcb.cpm" -nonetassembler
